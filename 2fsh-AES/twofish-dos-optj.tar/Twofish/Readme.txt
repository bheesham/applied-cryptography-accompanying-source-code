README

Algorithm:	Twofish
Submitter:	Bruce Schneier, John Kelsey, Doug Whiting, David Wagner,
		Chris Hall, and Niels Ferguson

-----------------------------------------------------------------

This directory contains the following files for the Twofish Java(TM) code:


Twofish.jar		.jar file for the Twofish algorithm


src:		Directory with Twofish source files
   Twofish_Algorithm.java		
   Twofish_Properties.java	


classes:	Directory with Twofish class files
   Twofish:
	Twofish.properties		


Readme.txt	This file


-----------------------------------------------------------------
TM: Java and Java-based marks are trademarks or registered 
trademarks of Sun Microsystems, Inc. in the United States and 
other countries.