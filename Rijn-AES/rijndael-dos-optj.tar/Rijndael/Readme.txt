README

Algorithm:	Rijndael
Submitter:	Joan Daemen and Vincent Rijmen
-----------------------------------------------------------
Optimised Java(TM)

This directory contains the following files:

Readme.txt			This file.

Rijndael.jar			.jar file for Rijndael

Rijndael.properties		Rijndael properties file
Rijndael_Algorithm.java		Rijndael Algorithm Java source
Rijndael_Properties.java	Rijndael Properties support code

-----------------------------------------------------------------
TM: Java and Java-based marks are trademarks or registered 
trademarks of Sun Microsystems, Inc. in the United States and 
other countries.